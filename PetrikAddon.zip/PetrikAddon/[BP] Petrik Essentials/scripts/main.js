import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const MENU_BUSY = new Set();

world.afterEvents.itemUse.subscribe((event) => {
  const player = event.source;
  const item = event.itemStack;

  if (!player || !item) return;

  if (item.typeId === "essemble:arcane_pulse") {
    openMenuSafely(player, openAdminMenu);
  }

  if (item.typeId === "essemble:guidebook") {
    openMenuSafely(player, openPlayerMenu);
  }
});

function openMenuSafely(player, menuFunction) {
  const key = player.id ?? player.name;
  if (MENU_BUSY.has(key)) return;

  MENU_BUSY.add(key);
  system.runTimeout(() => MENU_BUSY.delete(key), 20);
  system.run(() => menuFunction(player, key));
}

function finishMenu(key) {
  if (key) MENU_BUSY.delete(key);
}

function openAdminMenu(player, key) {
  player.playSound("random.orb", { volume: 0.6, pitch: 1.1 });

  const form = new ActionFormData()
    .title("PE_OWNER_UI")
    .body("")
    .button("§6BACKGROUND UI")
    .button("§6WARNA TOMBOL")
    .button("§6OWNER SETTING")
    .button("§6PLAYER SETTING")
    .button("§6RANK SETTING")
    .button("§6ITEM SETTING")
    .button("§6WORLD SETTING")
    .button("§6SERVER SETTING")
    .button("§6SOUND SETTING")
    .button("§6PARTICLE SETTING")
    .button("§6PERMISSION SETTING")
    .button("§cKEMBALI");

  form.show(player).then((response) => {
    finishMenu(key);
    if (response.canceled) return;

    switch (response.selection) {
      case 0:
        player.sendMessage("§eBACKGROUND UI sudah memakai frame custom yang sudah dirapikan.");
        break;
      case 1:
        player.sendMessage("§eWARNA TOMBOL belum dibuat.");
        break;
      case 2:
        player.sendMessage("§eOWNER SETTING belum dibuat.");
        break;
      case 3:
        player.sendMessage("§ePLAYER SETTING belum dibuat.");
        break;
      case 4:
        player.sendMessage("§eRANK SETTING belum dibuat.");
        break;
      case 5:
        player.sendMessage("§eITEM SETTING belum dibuat.");
        break;
      case 6:
        player.sendMessage("§eWORLD SETTING belum dibuat.");
        break;
      case 7:
        player.sendMessage("§eSERVER SETTING belum dibuat.");
        break;
      case 8:
        player.sendMessage("§eSOUND SETTING belum dibuat.");
        break;
      case 9:
        player.sendMessage("§ePARTICLE SETTING belum dibuat.");
        break;
      case 10:
        player.sendMessage("§ePERMISSION SETTING belum dibuat.");
        break;
      case 11:
        player.sendMessage("§cMenu ditutup.");
        break;
    }
  }).catch((error) => {
    finishMenu(key);
    console.warn(`Petrik Essentials ADMIN MENU error: ${error}`);
  });
}

function openPlayerMenu(player, key) {
  player.playSound("random.orb", { volume: 0.5, pitch: 1.2 });

  const form = new ActionFormData()
    .title("PE_PLAYER_UI")
    .body("")
    .button("§6PROFILE")
    .button("§6SETTING")
    .button("§6INFO")
    .button("§cKEMBALI");

  form.show(player).then((response) => {
    finishMenu(key);
    if (response.canceled) return;

    switch (response.selection) {
      case 0:
        player.sendMessage("§ePROFILE belum dibuat.");
        break;
      case 1:
        player.sendMessage("§eSETTING belum dibuat.");
        break;
      case 2:
        player.sendMessage("§eINFO belum dibuat.");
        break;
      case 3:
        player.sendMessage("§cMenu ditutup.");
        break;
    }
  }).catch((error) => {
    finishMenu(key);
    console.warn(`Petrik Essentials PLAYER MENU error: ${error}`);
  });
}
